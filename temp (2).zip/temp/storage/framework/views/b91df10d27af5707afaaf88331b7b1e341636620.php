<!DOCTYPE html>
<html>
<head>
<body>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src ="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>

        <style>
                body {
                    position: relative; 
                }
                #About {margin-top:50px;height:500px;color: #fff; background-color: tomato;}
                #WorkExperience{padding-top:50px;height:600px;color: #fff;background-color:grey;}
                #section3{padding-top:50px;height:500px;color: #fff;background-color:tomato;}
              
                </style>
              </head>
              
              <body data-spy="scroll" data-target=".navbar" data-offset="50">
              
              <nav class="navbar navbar-inverse navbar-sticky-top">
                <div class="container-fluid">
                  <div class="navbar-header">
                      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
              
                    <a class="navbar-brand" href="#">My portfolio in Laravel</a>
                  </div> 
              <div>
                <div class="collapse navbar-collapse " id="myNavbar"> 
                      <ul class="nav navbar-nav">
                        <li><a href="welcome">Welcome</a></li>
                       
                 
                        <li><a href="https://github.com/marishaS">Github</a></li>
                        <li><a href="https://www.linkedin.com/in/marishasingh/">LinkedIn</a></li>
                      </ul>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </nav>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1> Contact Me</h1>
            <hr>
     
            <form action="/action_page.php">
                First name:<br>
                <input type="text" name="firstname" value="Mickey"><br>
                Last name:<br>
                <input type="text" name="lastname" value="Mouse"><br><br>
                <input type="submit" value="Submit">
              </form>

<script>
$(document).ready(function(){
    $("#contactform").validate({
        rules: {
           verify_email:{
               required: true,
               email: true

           }
           
        }
    });
    

});
</script>

 

</body>
</head>
</html>
