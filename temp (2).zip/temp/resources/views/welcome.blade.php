<!DOCTYPE html>
<html>
<head>
  <title>Portfolio</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      position: relative; 
  }
  #About {margin-top:50px;height:500px;color: #fff; background-color: tomato;}
  #WorkExperience{padding-top:50px;height:600px;color: #fff;background-color:grey;}
  #section3{padding-top:50px;height:500px;color: #fff;background-color:tomato;}

  </style>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>                        
      </button>

      <a class="navbar-brand" href="#">My portfolio in Laravel</a>
    </div> 
<div>
  <div class="collapse navbar-collapse" id="myNavbar"> 
        <ul class="nav navbar-nav">
          <li><a href="#About">About Me</a></li>
          <li><a href="#WorkExperience">Work Experience</a></li>
          <li><a href="#section3">Education</a></li>
          <li><a href="">Contact Me</a></li>
          <li><a href="https://github.com/marishaS">Github</a></li>
          <li><a href="https://www.linkedin.com/in/marishasingh/">LinkedIn</a></li>
        </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>    
<div class="jumbotron">
        <h1 class="display-4">Welcome to my Website!!</h1>
        
   
      </div>

<div id="About" class="container-fluid">
 <h1>About Me</h1>
  <p style="color:black">Detail-oriented data engineer with 3+ years’ experience in Data Modelling and Business Intelligence</p>
<p style="color:black">Proficient with relational databases (Teradata, MySQL) and NoSQL databases (MongoDB, HBase)</p>
<p style="color:black">Knowledge of machine learning techniques and algorithms like Decision tree, Naïve Bayes and Random Forest</p>
<p style="color:black">  Utilized tools like R and Weka for analyzing and handling data and Tableau, QlikView for visualization intents</p>
<p style="color:black"> Hands-on experience with Python, Map Reduce and Scala programming for data pre-processing and analysis.</p>
</div>
<div id="WorkExperience" class="container-fluid">
  <h1>Work Experience</h1>
  <h3 style="color:black">Data Analyst, University of Illinois, Springfield  January 2017 - December 2017 </h3>
  <p style="color:black"> Built Tableau dashboards for actionable insights and data-driven decisions, reducing manual effort by 1 week</p>
<p style="color:black"> Applied data wrangling in python to examine gate count for traffic trends leading to better staffing decision</p>
<p style="color:black"> Analyzed data from different sources using Python, finding trendy products, improving purchasing decisions</p>
  <h3 style="color:black">Software Engineering Analyst, Accenture, India April 2014 - July 2016 </h3>
  <h5 style="color:black"><b>Data Management</b></h5>
  <p style="color:black"> Built Data Pipelines by creating and optimizing Teradata utilities, reducing data load time by 40%</p>
<p style="color:black">Applied views against tables to ease navigation and offer each business unit its own logical functionalization</p>
<p style="color:black">Analyzed change requests through requirement elicitation; Created data models for faster business reporting</p>
  <h5 style="color:black"><b>Data Reporting</b><h5>
<p style="color:black"> Worked closely with stakeholders, driving analytical applications through standard and custom SSRS reports</p>
<p style="color:black">Built reporting tables by aggregating data from multiple sources, reducing report generation time by 80%</p>
  <h5 style="color:black"><b>Process Improvement</b></h5>
  <p style="color:black">Led automation of batch jobs using UNIX shell scripts that improved efficiency by 60%</p>
<p style="color:black"> Generated dashboard using macros to monitor status of 1000+ batch jobs and send report</p>
<p style="color:black">Created performance tracking and success metrics for weekly and monthly reports to identify key trends</p>
</div>


<div id="section3" class="container-fluid">
  <h1  >Education</h1>
  <p style="text-align: left; width:49%; display: inline-block;font-size:20px" >University Of Illinois Springfield</p>
  <p style="text-align: right; width:20%;  display: inline-block;font-size:15px">August 2016 - December 2017</p>
  <p> MS IN CS</p>

  <p style="text-align: left; width:49%; display: inline-block;font-size:20px">Mody Institute</p>
  <p style="text-align: right; width:20%;  display: inline-block;font-size:15px">August 2016 - December 2017</p>
  <p> BACHELORS IN CS</p>
</div>



</body>
</html>
