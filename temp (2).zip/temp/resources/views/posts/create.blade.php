
<!DOCTYPE html>
<html>
<head>
  <title>Create your message</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
    
<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1>Create New Post</h1>
            <hr>

            {!! Form::open(['route' => 'posts.store']) !!}

            {{ Form::label('email', 'Email')}}
            {{Form::text('email', null,array('class'=>'form-control'))}}
           

            {{ Form::label('subject', 'Subject')}}
            {{Form::textarea('subject', null, array('class'=>'form-control'))}}

            {{ Form::label('body', 'Body')}}
            {{Form::textarea('body', null, array('class'=>'form-control'))}}

           
            {{Form::submit('Send Message',  array('class'=>'btn btn-success btn-lg'))}}

{!! Form::close() !!}

    
</div>
</html>
