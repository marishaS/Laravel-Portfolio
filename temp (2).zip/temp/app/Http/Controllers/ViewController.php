<?php

namespace App\Http\Controllers;

class ViewController extends Controller{

    public function getIndex(){
        return view('welcome');
    }}